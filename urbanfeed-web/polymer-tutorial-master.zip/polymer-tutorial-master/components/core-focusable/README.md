core-focusable
==============

owner: @morethanreal

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-focusable) for more information.
